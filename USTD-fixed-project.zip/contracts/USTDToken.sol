// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import "@openzeppelin/contracts/token/ERC20/ERC20.sol";
import "@openzeppelin/contracts/token/ERC20/extensions/ERC20Burnable.sol";

/**
 * @notice Fixed-supply BEP-20-compatible token for BNB Smart Chain.
 * @dev Not Tether/USDT, not USD-backed, and no dollar peg is promised.
 *      No privileged minting, blacklist, pause, or admin role is included.
 */
contract USTDToken is ERC20, ERC20Burnable {
    uint256 public constant INITIAL_SUPPLY = 1_000_000_000 * 10 ** 18;

    constructor() ERC20("USTD Token", "USTD") {
        _mint(msg.sender, INITIAL_SUPPLY);
    }
}
