const hre = require("hardhat");

async function main() {
  const [deployer] = await hre.ethers.getSigners();
  if (!deployer) throw new Error("No deployer wallet found. Set a TEST-WALLET PRIVATE_KEY in .env.");

  const balance = await hre.ethers.provider.getBalance(deployer.address);
  console.log("Network:", hre.network.name);
  console.log("Deployer:", deployer.address);
  console.log("Balance:", hre.ethers.formatEther(balance), "tBNB");

  const Token = await hre.ethers.getContractFactory("USTDToken");
  const token = await Token.deploy();
  const tx = token.deploymentTransaction();
  await token.waitForDeployment();

  const address = await token.getAddress();
  console.log("Deployment transaction:", tx ? tx.hash : "unknown");
  console.log("USTD contract:", address);
  console.log("BscScan Testnet:", `https://testnet.bscscan.com/address/${address}`);
}
main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
