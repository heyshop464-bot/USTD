const { expect } = require("chai");
const { ethers } = require("hardhat");

describe("USTDToken", function () {
  async function setup() {
    const [owner, recipient] = await ethers.getSigners();
    const Token = await ethers.getContractFactory("USTDToken");
    const token = await Token.deploy();
    await token.waitForDeployment();
    return { token, owner, recipient };
  }

  it("has expected metadata", async function () {
    const { token } = await setup();
    expect(await token.name()).to.equal("USTD Token");
    expect(await token.symbol()).to.equal("USTD");
    expect(await token.decimals()).to.equal(18);
  });

  it("mints one billion tokens to the deployer", async function () {
    const { token, owner } = await setup();
    const supply = ethers.parseUnits("1000000000", 18);
    expect(await token.totalSupply()).to.equal(supply);
    expect(await token.balanceOf(owner.address)).to.equal(supply);
  });

  it("transfers tokens", async function () {
    const { token, recipient } = await setup();
    const amount = ethers.parseUnits("125", 18);
    await token.transfer(recipient.address, amount);
    expect(await token.balanceOf(recipient.address)).to.equal(amount);
  });

  it("reverts when a wallet transfers more than its balance", async function () {
    const { token, recipient } = await setup();
    await expect(token.connect(recipient).transfer(recipient.address, 1n)).to.be.reverted;
  });

  it("allows holders to burn their own tokens", async function () {
    const { token, owner } = await setup();
    const amount = ethers.parseUnits("10", 18);
    const before = await token.totalSupply();
    await token.burn(amount);
    expect(await token.balanceOf(owner.address)).to.equal(before - amount);
    expect(await token.totalSupply()).to.equal(before - amount);
  });

  it("does not expose a public mint function", async function () {
    const { token } = await setup();
    expect(token.interface.hasFunction("mint(address,uint256)")).to.equal(false);
  });
});
