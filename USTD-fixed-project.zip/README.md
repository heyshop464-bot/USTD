# USTD — BNB Smart Chain Testnet project

This project contains a fixed-supply BEP-20-compatible token, Hardhat tests, a testnet deployment script, a static website, and a basic Node.js preview server.

## Token properties
- Name: USTD Token
- Symbol: USTD
- Initial supply: 1,000,000,000 USTD, 18 decimals
- Fixed supply; no privileged mint function
- Holders can burn their own tokens

**Disclosure:** USTD is not Tether/USDT, is not affiliated with Tether, is not USD-backed, and does not promise a $1 peg. This starter has not been independently audited.

## Test
Use Node.js 20+.

```bash
npm install
npm run compile
npm test
```

## Preview website
```bash
npm run web
```
Open the forwarded port 3000 in Codespaces.

## Testnet deployment
1. Create a dedicated test wallet with no real funds.
2. Obtain test tBNB from an official BNB Chain testnet faucet.
3. Copy `.env.example` to `.env` and enter the test-wallet private key locally.
4. Never commit `.env`, share a private key, or use a wallet containing real funds.
5. Run `npm run deploy:testnet`.

The script prints a contract address and deployment transaction hash. A successful deploy must be confirmed on https://testnet.bscscan.com. Downloading this project does not deploy it.

Docs: https://docs.bnbchain.org/bnb-smart-chain/developers/json_rpc/json-rpc-endpoint/
