require("@nomicfoundation/hardhat-toolbox");
require("dotenv").config();

const rpcUrl = process.env.BSC_TESTNET_RPC_URL || "https://bsc-testnet-dataseed.bnbchain.org";
const privateKey = process.env.PRIVATE_KEY || "";

module.exports = {
  solidity: {
    version: "0.8.24",
    settings: { optimizer: { enabled: true, runs: 200 } }
  },
  networks: {
    bscTestnet: {
      url: rpcUrl,
      chainId: 97,
      accounts: /^0x[0-9a-fA-F]{64}$/.test(privateKey) ? [privateKey] : []
    }
  }
};
